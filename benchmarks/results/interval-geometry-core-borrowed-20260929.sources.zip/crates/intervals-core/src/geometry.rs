use crate::{IntervalError, validate_intervals};

/// Connected components of half-open intervals, in original row order.
///
/// Nonempty rows are related by strict overlap, or by overlap and touching when
/// `include_touching` is true. Every empty row is an isolated component in both
/// modes. IDs are contiguous from zero, ordered by each component's first
/// original row. Permuting rows can therefore renumber components.
///
/// A start-sorted sweep tracks the furthest end of the current component. Every
/// joining row connects to a row attaining that end. At a boundary, no earlier
/// row can connect to any later row. A final original-row pass canonicalizes IDs.
/// Only endpoint comparisons are used. Runtime is `O(n log n)` and extra space
/// is `O(n)`, including output. Already start-sorted input takes `O(n)` time.
///
/// # Errors
///
/// Returns [`IntervalError::LengthMismatch`] for unequal slice lengths,
/// [`IntervalError::InvalidInterval`] for the first reversed original row, or
/// [`IntervalError::TooManyClusters`] if a component ID exceeds `u32::MAX`.
///
/// # Examples
///
/// ```
/// use intervals_core::cluster_intervals;
/// assert_eq!(cluster_intervals(&[10, 0, 1], &[12, 2, 3], false)?, [0, 1, 1]);
/// # Ok::<(), intervals_core::IntervalError>(())
/// ```
pub fn cluster_intervals<T: Ord + Copy>(
    starts: &[T],
    ends: &[T],
    include_touching: bool,
) -> Result<Vec<u32>, IntervalError> {
    let nonempty = validate(starts, ends)?;
    let mut records = Vec::with_capacity(nonempty);
    let mut labels = vec![0; starts.len()];
    let mut remap = Vec::<Option<u32>>::new();
    for (row, (&start, &end)) in starts.iter().zip(ends).enumerate() {
        if start < end {
            records.push((start, end, row));
        } else {
            labels[row] = cluster_id(remap.len() as u64)?;
            remap.push(None);
        }
    }
    if !records.is_sorted_by_key(|r| r.0) {
        records.sort_unstable_by_key(|r| r.0);
    }
    let mut frontier = None;
    let mut current = 0;
    for (start, end, row) in records {
        let separate = frontier.is_none_or(|right| {
            if include_touching {
                start > right
            } else {
                start >= right
            }
        });
        if separate {
            current = cluster_id(remap.len() as u64)?;
            remap.push(None);
            frontier = Some(end);
        } else {
            frontier = Some(frontier.unwrap().max(end));
        }
        labels[row] = current;
    }
    let mut next = 0;
    for label in &mut labels {
        let canonical = &mut remap[*label as usize];
        *label = match *canonical {
            Some(id) => id,
            None => {
                let id = cluster_id(next)?;
                *canonical = Some(id);
                next += 1;
                id
            }
        };
    }
    Ok(labels)
}

// Check IDs, not the component count: u32::MAX is a valid final ID.
fn cluster_id(id: u64) -> Result<u32, IntervalError> {
    u32::try_from(id).map_err(|_| IntervalError::TooManyClusters)
}

/// Canonical exact union as sorted, maximal nonempty half-open ranges.
///
/// Empty input rows contribute nothing. Overlapping and touching ranges always
/// coalesce. Each output end is strictly less than the following output start.
/// The output contains endpoints only, with no labels or multiplicities.
///
/// In start order, a row starting at or before the current maximum end extends
/// that exact covered run. A larger start establishes a positive uncovered gap.
/// Only endpoint comparisons are used. Runtime is `O(n + m log m + z)` and
/// extra space is `O(m + z)`, where `m` counts nonempty input rows and `z` counts
/// output ranges. Already start-sorted input takes `O(n + z)` time.
///
/// # Errors
///
/// Returns [`IntervalError::LengthMismatch`] for unequal slice lengths or
/// [`IntervalError::InvalidInterval`] for the first reversed original row.
///
/// # Examples
///
/// ```
/// use intervals_core::merge_intervals;
/// assert_eq!(merge_intervals(&[0, 2, 8], &[2, 4, 8])?, [(0, 4)]);
/// # Ok::<(), intervals_core::IntervalError>(())
/// ```
pub fn merge_intervals<T: Ord + Copy>(
    starts: &[T],
    ends: &[T],
) -> Result<Vec<(T, T)>, IntervalError> {
    let records = prepare(starts, ends, None)?;
    let mut output: Vec<(T, T)> = Vec::new();
    for (start, end) in records {
        if let Some(last) = output.last_mut()
            && start <= last.1
        {
            last.1 = last.1.max(end);
        } else {
            output.push((start, end));
        }
    }
    Ok(output)
}

/// Canonical complement of all intervals within `[domain_start, domain_end)`.
///
/// Validates every original row before clipping, including rows outside the
/// domain and rows supplied with an empty domain. Empty intervals never split
/// gaps. Empty input returns the whole nonempty domain. Equal bounds are valid
/// and produce no output. Output ranges are sorted and strictly separated.
///
/// After clipping and sorting, the cursor is the furthest covered boundary
/// already seen. A start beyond the cursor exposes exactly one uncovered gap.
/// The final cursor-to-domain-end range supplies any uncovered tail. No union
/// or label vector is materialized. Only endpoint comparisons are used.
/// Runtime is `O(n + m log m + z)` and extra space is `O(m + z)`, where `m`
/// counts clipped nonempty rows and `z` counts gaps. Ordered input is linear.
///
/// # Errors
///
/// Returns [`IntervalError::LengthMismatch`] for unequal slice lengths,
/// [`IntervalError::InvalidInterval`] for the first reversed original row, or
/// [`IntervalError::InvalidDomain`] for reversed domain bounds.
///
/// # Examples
///
/// ```
/// use intervals_core::interval_gaps;
/// assert_eq!(interval_gaps(&[1, 3], &[2, 5], 0, 6)?, [(0, 1), (2, 3), (5, 6)]);
/// # Ok::<(), intervals_core::IntervalError>(())
/// ```
pub fn interval_gaps<T: Ord + Copy>(
    starts: &[T],
    ends: &[T],
    domain_start: T,
    domain_end: T,
) -> Result<Vec<(T, T)>, IntervalError> {
    let records = prepare(starts, ends, Some((domain_start, domain_end)))?;
    let mut output = Vec::new();
    let mut cursor = domain_start;
    for (start, end) in records {
        if cursor < start {
            output.push((cursor, start));
        }
        cursor = cursor.max(end);
    }
    if cursor < domain_end {
        output.push((cursor, domain_end));
    }
    Ok(output)
}

fn validate<T: Ord + Copy>(starts: &[T], ends: &[T]) -> Result<usize, IntervalError> {
    validate_intervals(starts, ends)?;
    Ok(starts.iter().zip(ends).filter(|(s, e)| s < e).count())
}

fn prepare<T: Ord + Copy>(
    starts: &[T],
    ends: &[T],
    domain: Option<(T, T)>,
) -> Result<Vec<(T, T)>, IntervalError> {
    let nonempty = validate(starts, ends)?;
    if let Some((left, right)) = domain {
        if left > right {
            return Err(IntervalError::InvalidDomain);
        }
        if left == right {
            return Ok(Vec::new());
        }
    }
    // In a narrow domain most rows can disappear. Collect only the survivors,
    // avoiding an input-sized allocation when clipping discards nearly all rows.
    let mut records = if domain.is_none() {
        Vec::with_capacity(nonempty)
    } else {
        Vec::new()
    };
    for (&start, &end) in starts.iter().zip(ends) {
        let (start, end) = domain.map_or((start, end), |(left, right)| {
            (start.max(left), end.min(right))
        });
        if start < end {
            records.push((start, end));
        }
    }
    // Ends need not be sorted. Nested intervals are a common ordered input.
    if !records.is_sorted_by_key(|r| r.0) {
        records.sort_unstable_by_key(|r| r.0);
    }
    Ok(records)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn checked_cluster_ids_accept_the_maximum_id_not_only_the_count() {
        assert_eq!(cluster_id(u64::from(u32::MAX)), Ok(u32::MAX));
        assert_eq!(
            cluster_id(u64::from(u32::MAX) + 1),
            Err(IntervalError::TooManyClusters)
        );
        assert_eq!(cluster_id(u64::MAX), Err(IntervalError::TooManyClusters));
    }

    proptest::proptest! {
        #[test]
        fn checked_cluster_ids_match_the_uint32_range(id in proptest::prelude::any::<u64>()) {
            proptest::prop_assert_eq!(cluster_id(id).ok(), u32::try_from(id).ok());
        }
    }
}
