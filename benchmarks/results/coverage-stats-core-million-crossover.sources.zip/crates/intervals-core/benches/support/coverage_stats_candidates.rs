//! Private full-call offline sweep. Shares source preparation, not its oracle.
#[allow(dead_code)]
#[path = "../../src/coverage_stats.rs"]
mod preparation;

use intervals_core::{
    CoverageEndpoint, CoverageStats, CoverageStatsError, coverage_stats, validate_intervals,
};

pub const METHODS: &[&str] = &["binary", "sweep", "ordered", "hybrid"];

#[cfg(test)]
#[allow(dead_code)] // Also compiled by the harness-free benchmark's test target.
pub fn prefixes<T: CoverageEndpoint>(ss: &[T], se: &[T], boundaries: &[T]) -> Vec<i128> {
    let prepared = preparation::Prepared::new(ss, se);
    boundaries
        .iter()
        .map(|&x| {
            let k = prepared.union.partition_point(|&(_, end)| end <= x);
            prepared.prefix_at(x, k)
        })
        .collect()
}

pub fn run<T: CoverageEndpoint>(
    method: &str,
    qs: &[T],
    qe: &[T],
    ss: &[T],
    se: &[T],
) -> Result<Vec<CoverageStats>, CoverageStatsError> {
    if method == "binary" {
        return coverage_stats(qs, qe, ss, se);
    }
    assert!(["sweep", "ordered", "hybrid"].contains(&method));
    validate_intervals(qs, qe).map_err(CoverageStatsError::Queries)?;
    validate_intervals(ss, se).map_err(CoverageStatsError::Intervals)?;
    if qs.is_empty() {
        return Ok(Vec::new());
    }
    let prepared = preparation::Prepared::new(ss, se);
    if method != "sweep" {
        let ordered = qs.len() >= ss.len() && qs.is_sorted() && qe.is_sorted();
        if ordered || method == "ordered" || qs.len() < ss.len() || prepared.union.len() <= 1 {
            return direct(&prepared, qs, qe, ordered);
        }
    }
    sweep(&prepared, qs, qe)
}

fn direct<T: CoverageEndpoint>(
    prepared: &preparation::Prepared<T>,
    qs: &[T],
    qe: &[T],
    ordered: bool,
) -> Result<Vec<CoverageStats>, CoverageStatsError> {
    let (mut started, mut ended, mut left, mut right) = (0, 0, 0, 0);
    let mut output = Vec::with_capacity(qs.len());
    for (&a, &b) in qs.iter().zip(qe) {
        let query_length = b.widened() - a.widened();
        let (overlap_count, covered_length) = if a == b {
            (0, 0)
        } else {
            if ordered {
                while started < prepared.starts.len() && prepared.starts[started] < b {
                    started += 1;
                }
                while ended < prepared.ends.len() && prepared.ends[ended] <= a {
                    ended += 1;
                }
                while left < prepared.union.len() && prepared.union[left].1 <= a {
                    left += 1;
                }
                while right < prepared.union.len() && prepared.union[right].1 <= b {
                    right += 1;
                }
            } else {
                started = prepared.starts.partition_point(|&s| s < b);
                ended = prepared.ends.partition_point(|&e| e <= a);
                left = prepared.union.partition_point(|&(_, e)| e <= a);
                right = prepared.union.partition_point(|&(_, e)| e <= b);
            }
            let count = started
                .checked_sub(ended)
                .ok_or(CoverageStatsError::CountOverflow)?;
            (
                u64::try_from(count).map_err(|_| CoverageStatsError::CountOverflow)?,
                prepared.prefix_at(b, right) - prepared.prefix_at(a, left),
            )
        };
        output.push(CoverageStats {
            overlap_count,
            covered_length,
            query_length,
            covered_fraction: (a < b).then(|| covered_length as f64 / query_length as f64),
        });
    }
    Ok(output)
}

fn sweep<T: CoverageEndpoint>(
    prepared: &preparation::Prepared<T>,
    qs: &[T],
    qe: &[T],
) -> Result<Vec<CoverageStats>, CoverageStatsError> {
    let mut output: Vec<_> = qs
        .iter()
        .zip(qe)
        .map(|(&a, &b)| CoverageStats {
            overlap_count: 0,
            covered_length: 0,
            query_length: b.widened() - a.widened(),
            covered_fraction: (a < b).then_some(0.0),
        })
        .collect();
    // Packed requests keep the scan sequential. The two orders are independent:
    // start-sorted nested queries can have decreasing ends.
    let mut starts: Vec<_> = qs
        .iter()
        .zip(qe)
        .enumerate()
        .filter_map(|(i, (&a, &b))| (a < b).then_some((a, i)))
        .collect();
    let mut ends: Vec<_> = qs
        .iter()
        .zip(qe)
        .enumerate()
        .filter_map(|(i, (&a, &b))| (a < b).then_some((b, i)))
        .collect();
    if !starts.is_sorted_by_key(|r| r.0) {
        starts.sort_unstable_by_key(|r| r.0);
    }
    if !ends.is_sorted_by_key(|r| r.0) {
        ends.sort_unstable_by_key(|r| r.0);
    }
    let (mut ended, mut k) = (0, 0);
    for (a, i) in starts {
        while ended < prepared.ends.len() && prepared.ends[ended] <= a {
            ended += 1;
        }
        while k < prepared.union.len() && prepared.union[k].1 <= a {
            k += 1;
        }
        output[i].overlap_count =
            u64::try_from(ended).map_err(|_| CoverageStatsError::CountOverflow)?;
        output[i].covered_length = -prepared.prefix_at(a, k);
    }
    let (mut started, mut k) = (0, 0);
    for (b, i) in ends {
        while started < prepared.starts.len() && prepared.starts[started] < b {
            started += 1;
        }
        while k < prepared.union.len() && prepared.union[k].1 <= b {
            k += 1;
        }
        let count = u64::try_from(started).map_err(|_| CoverageStatsError::CountOverflow)?;
        let row = &mut output[i];
        row.overlap_count = count
            .checked_sub(row.overlap_count)
            .ok_or(CoverageStatsError::CountOverflow)?;
        row.covered_length += prepared.prefix_at(b, k);
        row.covered_fraction = Some(row.covered_length as f64 / row.query_length as f64);
    }
    Ok(output)
}
