//! Private full-call offline sweep. Shares source preparation, not its oracle.
#[allow(dead_code)]
#[path = "../../src/coverage_stats.rs"]
mod preparation;

use intervals_core::{
    CoverageEndpoint, CoverageStats, CoverageStatsError, coverage_stats, validate_intervals,
};

pub const METHODS: &[&str] = &["binary", "sweep"];

#[cfg(test)]
#[allow(dead_code)] // Also compiled by the harness-free benchmark's test target.
pub fn prefixes<T: CoverageEndpoint>(ss: &[T], se: &[T], boundaries: &[T]) -> Vec<i128> {
    let prepared = preparation::Prepared::new(ss, se);
    boundaries
        .iter()
        .map(|&x| {
            let k = prepared.union.partition_point(|&(_, end)| end <= x);
            prepared.prefix_at(x, k)
        })
        .collect()
}

pub fn run<T: CoverageEndpoint>(
    method: &str,
    qs: &[T],
    qe: &[T],
    ss: &[T],
    se: &[T],
) -> Result<Vec<CoverageStats>, CoverageStatsError> {
    if method == "binary" {
        return coverage_stats(qs, qe, ss, se);
    }
    assert_eq!(method, "sweep");
    validate_intervals(qs, qe).map_err(CoverageStatsError::Queries)?;
    validate_intervals(ss, se).map_err(CoverageStatsError::Intervals)?;
    if qs.is_empty() {
        return Ok(Vec::new());
    }
    let prepared = preparation::Prepared::new(ss, se);
    let mut output: Vec<_> = qs
        .iter()
        .zip(qe)
        .map(|(&a, &b)| CoverageStats {
            overlap_count: 0,
            covered_length: 0,
            query_length: b.widened() - a.widened(),
            covered_fraction: (a < b).then_some(0.0),
        })
        .collect();
    // Packed requests keep the scan sequential. The two orders are independent:
    // start-sorted nested queries can have decreasing ends.
    let mut starts: Vec<_> = qs
        .iter()
        .zip(qe)
        .enumerate()
        .filter_map(|(i, (&a, &b))| (a < b).then_some((a, i)))
        .collect();
    let mut ends: Vec<_> = qs
        .iter()
        .zip(qe)
        .enumerate()
        .filter_map(|(i, (&a, &b))| (a < b).then_some((b, i)))
        .collect();
    if !starts.is_sorted_by_key(|r| r.0) {
        starts.sort_unstable_by_key(|r| r.0);
    }
    if !ends.is_sorted_by_key(|r| r.0) {
        ends.sort_unstable_by_key(|r| r.0);
    }
    let (mut ended, mut k) = (0, 0);
    for (a, i) in starts {
        while ended < prepared.ends.len() && prepared.ends[ended] <= a {
            ended += 1;
        }
        while k < prepared.union.len() && prepared.union[k].1 <= a {
            k += 1;
        }
        output[i].overlap_count =
            u64::try_from(ended).map_err(|_| CoverageStatsError::CountOverflow)?;
        output[i].covered_length = -prepared.prefix_at(a, k);
    }
    let (mut started, mut k) = (0, 0);
    for (b, i) in ends {
        while started < prepared.starts.len() && prepared.starts[started] < b {
            started += 1;
        }
        while k < prepared.union.len() && prepared.union[k].1 <= b {
            k += 1;
        }
        let count = u64::try_from(started).map_err(|_| CoverageStatsError::CountOverflow)?;
        let row = &mut output[i];
        row.overlap_count = count
            .checked_sub(row.overlap_count)
            .ok_or(CoverageStatsError::CountOverflow)?;
        row.covered_length += prepared.prefix_at(b, k);
        row.covered_fraction = Some(row.covered_length as f64 / row.query_length as f64);
    }
    Ok(output)
}
