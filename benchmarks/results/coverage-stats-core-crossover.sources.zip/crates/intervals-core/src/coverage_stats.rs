use crate::{CoverageEndpoint, IntervalError, geometry::merge_sorted, validate_intervals};
use std::fmt;

/// Exact source-row count and union coverage for one query interval.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CoverageStats {
    pub overlap_count: u64,
    pub covered_length: i128,
    pub query_length: i128,
    /// Integer lengths are converted separately to `f64`, then divided.
    /// Empty queries have `None`. Exact integer columns remain authoritative.
    pub covered_fraction: Option<f64>,
}

/// Invalid input to per-query coverage statistics.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CoverageStatsError {
    Queries(IntervalError),
    Intervals(IntervalError),
    /// A source count cannot be represented as `u64`, or count subtraction failed.
    CountOverflow,
}

impl fmt::Display for CoverageStatsError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Queries(error) => write!(f, "queries: {error}"),
            Self::Intervals(error) => write!(f, "intervals: {error}"),
            Self::CountOverflow => write!(f, "intervals: source count exceeds the UInt64 range"),
        }
    }
}

impl std::error::Error for CoverageStatsError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Queries(error) | Self::Intervals(error) => Some(error),
            Self::CountOverflow => None,
        }
    }
}

// Shared with the private offline-sweep benchmark through a #[path] import.
pub(crate) struct Prepared<T> {
    pub(crate) starts: Vec<T>,
    pub(crate) ends: Vec<T>,
    pub(crate) union: Vec<(T, T)>,
    pub(crate) prefixes: Vec<i128>,
}

impl<T: CoverageEndpoint> Prepared<T> {
    // Call only after validating every row in both operands.
    pub(crate) fn new(starts: &[T], ends: &[T]) -> Self {
        let mut records: Vec<_> = starts
            .iter()
            .zip(ends)
            .filter_map(|(&s, &e)| (s < e).then_some((s, e)))
            .collect();
        if !records.is_sorted_by_key(|r| r.0) {
            records.sort_unstable_by_key(|r| r.0);
        }
        let (starts, mut ends): (Vec<_>, Vec<_>) = records.iter().copied().unzip();
        if !ends.is_sorted() {
            ends.sort_unstable();
        }
        let union = merge_sorted(records.into_iter());
        let mut prefixes = Vec::with_capacity(union.len() + 1);
        prefixes.push(0);
        for &(start, end) in &union {
            // Disjoint runs sum to at most the coordinate span, <= u64::MAX.
            prefixes.push(prefixes.last().unwrap() + end.widened() - start.widened());
        }
        Self {
            starts,
            ends,
            union,
            prefixes,
        }
    }

    pub(crate) fn prefix_at(&self, x: T, k: usize) -> i128 {
        self.prefixes[k]
            + if k < self.union.len() && self.union[k].0 < x {
                x.widened() - self.union[k].0.widened()
            } else {
                0
            }
    }

    fn prefix(&self, x: T) -> i128 {
        self.prefix_at(x, self.union.partition_point(|&(_, end)| end <= x))
    }
}

/// Count original source rows and measure their union inside each query.
///
/// All intervals are half-open. Empty queries give `(0, 0, 0, None)`.
/// Empty sources have no effect. Duplicate sources increase counts independently.
/// Query rows remain separate and retain their original order. A row overlaps
/// its own source copy when both operands are the same collection.
///
/// For a nonempty `[a,b)`, every source ending at or before `a` also starts
/// before `b`. Subtracting those rows from all starts strictly before `b`
/// therefore counts exactly the overlapping original rows, including duplicates.
///
/// Source union runs are disjoint and sorted. For boundary `x`, completed runs
/// supply their cumulative length and at most one next run supplies a partial
/// length. Thus `F(b)-F(a)` measures union coverage, including gaps correctly.
/// Prefix arithmetic widens before subtraction and remains exact in `i128`.
/// The sealed endpoint domain bounds each union's length by `u64::MAX`.
/// Fractions cast each exact length to `f64` and then divide, without clamping.
///
/// Time is `O(m log(m+1) + n log(m+1) + n)` for `n` queries and `m` sources.
/// Space is `O(m+n)`, including output. Verified source order avoids its sort.
///
/// # Errors
///
/// Both original operands validate before preparation or empty shortcuts.
/// Errors identify `queries` or `intervals` and the original operand row.
/// Operand row counts may differ. Count conversions and subtraction are checked.
///
/// # Examples
///
/// ```
/// let rows = intervals_core::coverage_stats(&[0, 5, 12, 7], &[10, 10, 15, 7],
///                                           &[1, 4], &[7, 9])?;
/// assert_eq!(rows[0].overlap_count, 2);
/// assert_eq!(rows[0].covered_length, 8);
/// assert_eq!(rows[3].covered_fraction, None);
/// # Ok::<(), intervals_core::CoverageStatsError>(())
/// ```
pub fn coverage_stats<T: CoverageEndpoint>(
    query_starts: &[T],
    query_ends: &[T],
    interval_starts: &[T],
    interval_ends: &[T],
) -> Result<Vec<CoverageStats>, CoverageStatsError> {
    validate_intervals(query_starts, query_ends).map_err(CoverageStatsError::Queries)?;
    validate_intervals(interval_starts, interval_ends).map_err(CoverageStatsError::Intervals)?;
    if query_starts.is_empty() {
        return Ok(Vec::new());
    }
    let prepared = Prepared::new(interval_starts, interval_ends);
    query_starts
        .iter()
        .zip(query_ends)
        .map(|(&a, &b)| {
            let query_length = b.widened() - a.widened();
            let (overlap_count, covered_length) = if a == b {
                (0, 0)
            } else {
                let started = prepared.starts.partition_point(|&s| s < b);
                let ended = prepared.ends.partition_point(|&e| e <= a);
                let count = started
                    .checked_sub(ended)
                    .ok_or(CoverageStatsError::CountOverflow)?;
                (
                    u64::try_from(count).map_err(|_| CoverageStatsError::CountOverflow)?,
                    prepared.prefix(b) - prepared.prefix(a),
                )
            };
            Ok(CoverageStats {
                overlap_count,
                covered_length,
                query_length,
                covered_fraction: (a < b).then(|| covered_length as f64 / query_length as f64),
            })
        })
        .collect()
}
