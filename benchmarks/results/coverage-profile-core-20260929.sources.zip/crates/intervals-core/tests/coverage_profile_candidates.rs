#[path = "../benches/support/coverage_profile_candidates.rs"]
mod candidates;

use candidates::{METHODS, oracle, run};
use intervals_core::{CoverageSegment, IntervalError};
use proptest::prelude::*;

fn check<T: Ord + Copy + std::fmt::Debug>(s: &[T], e: &[T], w: &[i128], domain: Option<(T, T)>) {
    for zero in [false, true] {
        for weights in [None, Some(w)] {
            let expected = oracle(s, e, weights, domain, zero);
            for method in METHODS {
                assert_eq!(
                    run(method, s, e, weights, domain, zero),
                    expected,
                    "{method}"
                );
            }
        }
    }
}

#[test]
fn empty_zero_gap_ties_and_full_heap_tail() {
    for domain in [None, Some((-10, 40)), Some((2, 2)), Some((3, 6))] {
        check::<i64>(&[], &[], &[], domain);
        check(
            &[0, 1, 2, 30],
            &[0, 1, 2, 30],
            &[4, 0, i128::MAX, 5],
            domain,
        );
        check(&[0, 2, 5, 3], &[4, 5, 7, 3], &[2, 3, 3, 8], domain);
        check(&[0, 4], &[2, 6], &[7, 7], domain);
        check(
            &[0, 0, 0, 1, 2, 3],
            &[7, 6, 4, 5, 3, 4],
            &[3, 2, 1, 0, 3, 3],
            domain,
        );
        check(
            &[0, 10, -20, 200],
            &[100, 20, -20, 200],
            &[0, 7, 8, 9],
            domain,
        );
    }
}

#[test]
fn all_candidates_accept_generic_extreme_endpoints_and_exact_loads() {
    check(
        &['a', 'c', 'b'],
        &['c', 'd', 'c'],
        &[8, 8, 0],
        Some(('a', 'z')),
    );
    check(&[i64::MIN, 0], &[0, i64::MAX], &[i128::MAX; 2], None);
    check(&[0, u64::MAX - 1], &[1, u64::MAX], &[i128::MAX; 2], None);
    check(&[i8::MIN, 0], &[0, i8::MAX], &[7, 7], None);
    check(&[0, 0], &[2, 2], &[i128::from(u64::MAX); 2], None);
    check(&[0, 0], &[2, 1], &[i128::MAX, 1], Some((1, 2)));
    check(&[0, 0], &[2, 1], &[i128::MAX, 1], Some((1, 1)));
    check(&[0, 0], &[2, 1], &[i128::MAX, 1], None);
}

#[test]
fn all_candidates_validate_original_indices_before_pruning() {
    for method in METHODS {
        for domain in [None, Some((0, 0)), Some((10, 20))] {
            assert_eq!(
                run(
                    method,
                    &[0, 2],
                    &[0, 1],
                    Some(&[0i128, 0][..]),
                    domain,
                    false
                ),
                Err(IntervalError::InvalidInterval { index: 1 })
            );
            assert_eq!(
                run(
                    method,
                    &[0, 2],
                    &[0, 2],
                    Some(&[0i128, -1][..]),
                    domain,
                    false
                ),
                Err(IntervalError::NegativeLoad { index: 1 })
            );
        }
        assert!(matches!(
            run(method, &[0], &[], None::<&[i128]>, None, false),
            Err(IntervalError::LengthMismatch(_))
        ));
        assert!(matches!(
            run(method, &[0], &[1], Some(&[] as &[i128]), None, false),
            Err(IntervalError::LengthMismatch(_))
        ));
        assert_eq!(
            run(method, &[0], &[0], None::<&[i128]>, Some((2, 1)), false),
            Err(IntervalError::InvalidDomain)
        );
    }
}

#[test]
fn tiny_per_tick_oracle_independently_checks_breakpoints() {
    let (starts, ends, weights) = ([4, 1, -3, 0, 2], [7, 7, 0, 2, 2], [3i128, 0, 4, 4, 99]);
    for method in METHODS {
        let profile = run(method, &starts, &ends, Some(&weights), Some((-5, 10)), true).unwrap();
        for tick in -5..10 {
            let expected: i128 = (0..starts.len())
                .filter(|&i| starts[i] <= tick && tick < ends[i])
                .map(|i| weights[i])
                .sum();
            let actual = profile
                .iter()
                .find(|p| p.start <= tick && tick < p.end)
                .unwrap();
            assert_eq!(actual.load, expected, "{method}, tick={tick}");
        }
    }
}

proptest! {
    #[test]
    fn every_candidate_matches_membership_and_tick_oracles(
        rows in prop::collection::vec((-12i64..=12, -12i64..=12, 0i128..=9), 0..40),
        bounds in prop::option::of((-15i64..=15, -15i64..=15)),
        zero in any::<bool>(),
    ) {
        let (s, e): (Vec<_>, Vec<_>) = rows.iter().map(|&(a,b,_)| (a.min(b), a.max(b))).unzip();
        let weights: Vec<_> = rows.iter().map(|r| r.2).collect();
        let domain = bounds.map(|(a,b)| (a.min(b), a.max(b)));
        for w in [None, Some(weights.as_slice())] {
            let expected = oracle(&s, &e, w, domain, zero).unwrap();
            for method in METHODS {
                let actual = run(method, &s, &e, w, domain, zero).unwrap();
                prop_assert_eq!(&actual, &expected);
                prop_assert!(actual.len() <= 2 * s.len() + 1);
                for segment in &actual {
                    prop_assert!(segment.start < segment.end);
                    prop_assert!(segment.load >= i128::from(!zero));
                    for point in [segment.start, segment.end] {
                        prop_assert!(s.contains(&point) || e.contains(&point)
                            || domain.is_some_and(|(a,b)| point == a || point == b));
                    }
                }
                for pair in actual.windows(2) {
                    prop_assert!(pair[0].end <= pair[1].start);
                    prop_assert!(pair[0].end != pair[1].start || pair[0].load != pair[1].load);
                }
                for tick in -15..15 {
                    let in_domain = domain.is_none_or(|(a,b)| a <= tick && tick < b);
                    let want: i128 = if in_domain {
                        (0..s.len()).filter(|&i| s[i] <= tick && tick < e[i]).map(|i| w.map_or(1, |w| w[i])).sum()
                    } else { 0 };
                    let got = actual.iter().find(|p| p.start <= tick && tick < p.end).map_or(0, |p| p.load);
                    prop_assert_eq!(got, want);
                }
                let reversed_s: Vec<_> = s.iter().rev().copied().collect();
                let reversed_e: Vec<_> = e.iter().rev().copied().collect();
                let reversed_w: Vec<_> = weights.iter().rev().copied().collect();
                let reversed = run(method, &reversed_s, &reversed_e, w.map(|_| reversed_w.as_slice()), domain, zero).unwrap();
                prop_assert_eq!(&actual, &reversed);
                let profile_s: Vec<_> = actual.iter().map(|p| p.start).collect();
                let profile_e: Vec<_> = actual.iter().map(|p| p.end).collect();
                let profile_w: Vec<_> = actual.iter().map(|p| p.load).collect();
                let repeated = run(method, &profile_s, &profile_e, Some(profile_w.as_slice()), domain, zero).unwrap();
                prop_assert_eq!(&actual, &repeated);
                let _typed_output: &[CoverageSegment<i64>] = &actual;
            }
        }
    }
}
